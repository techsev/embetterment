# Grunt: The JavaScript Task Runner [![Build Status](https://secure.travis-ci.org/gruntjs/grunt.png?branch=master)](http://travis-ci.org/gruntjs/grunt)

### Documentation

Visit the [gruntjs.com](http://gruntjs.com/) website for all the things.

### Support / Contributing
Before you make an issue, please read our [Contributing](http://gruntjs.com/contributing) guide.

You can find the grunt team in [#grunt on irc.freenode.net](irc://irc.freenode.net/#grunt).

### Release History
See the [CHANGELOG](CHANGELOG).
